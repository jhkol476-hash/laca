# 3D Model Viewer - Demo

Progetto d'esempio: sito statico per visualizzare modelli 3D (glTF/glb, OBJ).

Funzionalità incluse:
- Visualizzazione con three.js
- Drag & drop file
- Caricamento da file input
- Caricamento da URL pubblico
- Supporto glTF/GLB via GLTFLoader (+ DRACO opzionale)
- Supporto base per OBJ via OBJLoader
- Orbit controls, griglia e posizionamento automatico del modello

Come usare:
1. Scarica i file (index.html, app.js, styles.css, README.md).
2. Apri `index.html` in un browser moderno (Chrome/Edge/Firefox).
   - Per caricare un file locale trascina il file sulla zona centrale o usa il pulsante "file".
   - Per caricare da URL incolla l'URL e clicca "Carica da URL" (attenzione a CORS: il server deve permettere richieste cross-origin).
3. Per aggiungere altri loader (FBX, STL, ecc.) includi il relativo loader di three.js e aggiungi la logica di parsing in `app.js`.

Note e miglioramenti possibili:
- Hosting statico: GitHub Pages, Netlify o Vercel.
- Gestione CORS per URL esterni: se il file è ospitato senza header CORS, il browser bloccherà la fetch.
- Aggiungere toolbox per modificare luci/materiali, esportare screenshot, misure, ecc.
- Supporto a file compressi/draco: assicurati di impostare correttamente `DRACOLoader.setDecoderPath`.
- Aggiungere preview thumbnail e lista modelli caricati.

Se vuoi, posso:
- Estendere il viewer per autenticazione e integrazione con un servizio di terze parti (es. Sketchfab).
- Aggiungere supporto per altri formati (FBX/STL/PLY).
- Preparare un template pronto per deploy su GitHub Pages con build script.
- Aggiungere test automatici e pipeline CI.

Dimmi se intendevi "3D" o "third-party" e quali formati/feature vuoi prioritizzare — procedo subito a estendere il codice o a preparare il deploy.