// Semplice viewer three.js con drag&drop e caricamento da file/URL
(() => {
  const canvas = document.getElementById('c');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(window.innerWidth, window.innerHeight);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf0f0f0);

  const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 2000);
  camera.position.set(0, 1.2, 3);

  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.target.set(0, 0.8, 0);
  controls.update();

  // Lights
  const hemi = new THREE.HemisphereLight(0xffffff, 0x888888, 0.8);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xffffff, 0.6);
  dir.position.set(5, 10, 7.5);
  scene.add(dir);

  // Grid & ground
  const grid = new THREE.GridHelper(10, 20, 0x888888, 0xdddddd);
  scene.add(grid);

  const groundMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, metalness: 0 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(50, 50), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.001;
  ground.receiveShadow = true;
  scene.add(ground);

  let currentModel = null;

  function clearModel() {
    if (!currentModel) return;
    scene.remove(currentModel);
    currentModel.traverse((c) => {
      if (c.geometry) c.geometry.dispose();
      if (c.material) {
        if (Array.isArray(c.material)) c.material.forEach(m => m.dispose());
        else c.material.dispose();
      }
    });
    currentModel = null;
  }

  // Loaders
  const gltfLoader = new THREE.GLTFLoader();
  const dracoLoader = new THREE.DRACOLoader();
  // Set path to DRACO libs if using compression; CDN used here (optional)
  dracoLoader.setDecoderPath('https://www.gstatic.com/draco/v1/decoders/');
  gltfLoader.setDRACOLoader(dracoLoader);

  const objLoader = new THREE.OBJLoader();

  function centerAndScale(obj) {
    // Compute bounding box
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    box.getSize(size);
    const maxDim = Math.max(size.x, size.y, size.z);
    if (maxDim > 0) {
      const scale = 1.5 / maxDim;
      obj.scale.setScalar(scale);
    }
    // Center
    const center = new THREE.Vector3();
    box.getCenter(center);
    obj.position.sub(center.multiplyScalar(obj.scale.x));
    obj.position.y += (size.y * obj.scale.x) / 2; // sit on ground
  }

  function addModelToScene(obj) {
    clearModel();
    currentModel = obj;
    centerAndScale(obj);
    scene.add(obj);
  }

  function loadArrayBufferAsModel(buffer, filename) {
    const lower = filename.toLowerCase();
    if (lower.endsWith('.glb') || lower.endsWith('.gltf')) {
      gltfLoader.parse(buffer, '', (gltf) => {
        addModelToScene(gltf.scene);
      }, (err) => {
        alert('Errore parsing glTF: ' + err.message);
        console.error(err);
      });
    } else if (lower.endsWith('.obj')) {
      const text = new TextDecoder().decode(buffer);
      const obj = objLoader.parse(text);
      addModelToScene(obj);
    } else {
      alert('Formato non supportato: ' + filename);
    }
  }

  function loadFromFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target.result;
      // glb -> ArrayBuffer; obj -> text
      if (file.name.toLowerCase().endsWith('.obj')) {
        loadArrayBufferAsModel(result, file.name);
      } else {
        loadArrayBufferAsModel(result, file.name);
      }
    };
    // Always read as ArrayBuffer to use gltfLoader.parse
    reader.readAsArrayBuffer(file);
  }

  async function loadFromUrl(url) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const contentType = res.headers.get('content-type') || '';
      const buffer = await res.arrayBuffer();
      // guess filename from url
      const filename = url.split('?')[0].split('/').pop() || 'model';
      loadArrayBufferAsModel(buffer, filename);
    } catch (err) {
      alert('Errore caricamento URL: ' + err.message);
      console.error(err);
    }
  }

  // UI wiring
  const fileInput = document.getElementById('fileInput');
  fileInput.addEventListener('change', (ev) => {
    if (ev.target.files.length) loadFromFile(ev.target.files[0]);
    ev.target.value = '';
  });

  const urlInput = document.getElementById('urlInput');
  document.getElementById('loadUrl').addEventListener('click', () => {
    const url = urlInput.value.trim();
    if (!url) return alert('Inserisci un URL');
    loadFromUrl(url);
  });

  // drag & drop
  const viewer = document.getElementById('viewer');
  const dropHint = document.getElementById('dropHint');
  ['dragenter', 'dragover'].forEach(ev => viewer.addEventListener(ev, (e) => {
    e.preventDefault(); e.stopPropagation(); dropHint.classList.add('active');
  }));
  ['dragleave', 'drop'].forEach(ev => viewer.addEventListener(ev, (e) => {
    e.preventDefault(); e.stopPropagation(); dropHint.classList.remove('active');
  }));
  viewer.addEventListener('drop', (e) => {
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      loadFromFile(e.dataTransfer.files[0]);
    }
  });

  // extras
  document.getElementById('showGrid').addEventListener('change', (e) => grid.visible = e.target.checked);
  document.getElementById('autoRotate').addEventListener('change', (e) => {
    controls.autoRotate = e.target.checked;
  });

  // Resize
  window.addEventListener('resize', onWindowResize);
  function onWindowResize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  // Animation loop
  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);
    const dt = clock.getDelta();
    controls.update();
    renderer.render(scene, camera);
  }
  animate();

  // Expose for debug
  window.viewerAPI = {
    loadFromUrl,
    loadFromFile,
    clearModel
  };
})();